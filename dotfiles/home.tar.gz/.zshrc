# If you come from bash you might have to change your $PATH.
# export PATH=$HOME/bin:/usr/local/bin:$PATH

# Path to your oh-my-zsh installation.
export ZSH="/home/$USER/.oh-my-zsh"

# Set name of the theme to load --- if set to "random", it will
# load a random theme each time oh-my-zsh is loaded, in which case,
# to know which specific one was loaded, run: echo $RANDOM_THEME
# See https://github.com/robbyrussell/oh-my-zsh/wiki/Themes
ZSH_THEME="robbyrussell"
fpath+=~/.zfunc
# Set list of themes to pick from when loading at random
# Setting this variable when ZSH_THEME=random will cause zsh to load
# a theme from this variable instead of looking in ~/.oh-my-zsh/themes/
# If set to an empty array, this variable will have no effect.
# ZSH_THEME_RANDOM_CANDIDATES=( "robbyrussell" "agnoster" )

# Uncomment the following line to use case-sensitive completion.
# CASE_SENSITIVE="true"

# Uncomment the following line to use hyphen-insensitive completion.
# Case-sensitive completion must be off. _ and - will be interchangeable.
# HYPHEN_INSENSITIVE="true"

# Uncomment the following line to disable bi-weekly auto-update checks.
# DISABLE_AUTO_UPDATE="true"

# Uncomment the following line to automatically update without prompting.
# DISABLE_UPDATE_PROMPT="true"

# Uncomment the following line to change how often to auto-update (in days).
# export UPDATE_ZSH_DAYS=13

# Uncomment the following line if pasting URLs and other text is messed up.
# DISABLE_MAGIC_FUNCTIONS=true

# Uncomment the following line to disable colors in ls.
# DISABLE_LS_COLORS="true"

# Uncomment the following line to disable auto-setting terminal title.
# DISABLE_AUTO_TITLE="true"

# Uncomment the following line to enable command auto-correction.
# ENABLE_CORRECTION="true"

# Uncomment the following line to display red dots whilst waiting for completion.
COMPLETION_WAITING_DOTS="true"

# Uncomment the following line if you want to disable marking untracked files
# under VCS as dirty. This makes repository status check for large repositories
# much, much faster.
# DISABLE_UNTRACKED_FILES_DIRTY="true"

# Uncomment the following line if you want to change the command execution time
# stamp shown in the history command output.
# You can set one of the optional three formats:
# "mm/dd/yyyy"|"dd.mm.yyyy"|"yyyy-mm-dd"
# or set a custom format using the strftime function format specifications,
# see 'man strftime' for details.
# HIST_STAMPS="mm/dd/yyyy"

# Would you like to use another custom folder than $ZSH/custom?
# ZSH_CUSTOM=/path/to/new-custom-folder

# Which plugins would you like to load?
# Standard plugins can be found in ~/.oh-my-zsh/plugins/*
# Custom plugins may be added to ~/.oh-my-zsh/custom/plugins/
# Example format: plugins=(rails git textmate ruby lighthouse)
# Add wisely, as too many plugins slow down shell startup.
plugins=(git sudo docker docker-compose man autojump git-flow gpg-agent archlinux alias-finder aws nats)

source $ZSH/oh-my-zsh.sh
alias ls="eza --icons=always --group-directories-first --color=always --git"
alias l="ls -la"
alias vim=$EDITOR
alias rcheck="cargo check && fd .rs -F | xargs touch && cargo clippy && cargo test"
alias lg="lazygit"
alias dcd="docker-compose down"
alias dcdv="docker-compose down -v"
alias dcu="docker-compose up"
alias dcub="docker-compose up --build"
alias drm="docker rm"
alias dcp="docker cp"
alias dst="docker stop"
alias dps="docker ps -a"
alias dpsq="docker ps -aq"
alias poop='git push origin "$(git branch | grep "\*" | cut -d " " -f2)"'
alias vommit='git commit -sS'
alias eat_shit='git pull origin "$(git branch | grep "\*" | cut -d " " -f2)"'
alias cat="bat"
alias dips='docker compose ps -q | xargs docker inspect -f "{{.Name}} {{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}"'
alias мшь="$EDITOR"
alias tf="terraform"
alias vterm="vim -c \"startinsert\" -c \":term\""
# User configuration

# export MANPATH="/usr/local/man:$MANPATH"

# You may need to manually set your language environment
# export LANG=en_US.UTF-8

# Compilation flags
# export ARCHFLAGS="-arch x86_64"

# Set personal aliases, overriding those provided by oh-my-zsh libs,
# plugins, and themes. Aliases can be placed here, though oh-my-zsh
# users are encouraged to define aliases within the ZSH_CUSTOM folder.
# For a full list of active aliases, run `alias`.
#
# Example aliases
# alias zshconfig="mate ~/.zshrc"
# alias ohmyzsh="mate ~/.oh-my-zsh"

compinit

autoload -U +X bashcompinit && bashcompinit
autoload -U ~/.zfunc/*
source ~/.zshalias

source /usr/share/zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
source /usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh
command -v mise &>/dev/null && eval "$(mise activate zsh)"
eval "$(starship init zsh)"
# eval "$(mise activate zsh)"

pya

autoload -Uz compinit
zstyle ':completion:*' menu select

# pnpm
export PNPM_HOME="/home/$USER/.local/share/pnpm"
case ":$PATH:" in
  *":$PNPM_HOME:"*) ;;
  *) export PATH="$PNPM_HOME:$PATH" ;;
esac
# pnpm end

## [Completion]
## Completion scripts setup. Remove the following line to uninstall
[[ -f /home/s3rius/.config/.dart-cli-completion/zsh-config.zsh ]] && . /home/s3rius/.config/.dart-cli-completion/zsh-config.zsh || true
## [/Completion]


[[ -f "$HOME/.local/bin/env" ]] && . "$HOME/.local/bin/env"

emulate sh -c 'source /etc/profile'

[[ "$TERM_PROGRAM" == "kiro" ]] && . "$(kiro --locate-shell-integration-path zsh)"
